# Stored Procedures
```sql
CREATE PROCEDURE procedure_name AS BEGIN SELECT * FROM table_name; END;
```