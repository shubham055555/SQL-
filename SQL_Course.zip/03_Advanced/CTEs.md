# CTEs
```sql
WITH cte_name AS (SELECT * FROM table_name) SELECT * FROM cte_name;
```