# Query Optimization Tips
- Use Indexes
- Avoid SELECT *
- Use WHERE clauses properly
