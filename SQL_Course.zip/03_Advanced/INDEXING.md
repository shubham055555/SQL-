# Indexing
```sql
CREATE INDEX index_name ON table_name (column);
```