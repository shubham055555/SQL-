# Window Functions
```sql
SELECT column, ROW_NUMBER() OVER (ORDER BY column) FROM table_name;
```