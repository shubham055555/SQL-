# HAVING Clause
```sql
SELECT column, COUNT(*) FROM table_name GROUP BY column HAVING COUNT(*) > 1;
```