# GROUP BY
```sql
SELECT column, COUNT(*) FROM table_name GROUP BY column;
```