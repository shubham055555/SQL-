# VIEWS
```sql
CREATE VIEW view_name AS SELECT column1, column2 FROM table_name;
```