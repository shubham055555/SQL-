# Subqueries
```sql
SELECT column1 FROM (SELECT column1 FROM table_name) AS sub;
```