-- Basic SQL Practice
SELECT * FROM employees;
INSERT INTO employees (name, role) VALUES ('Alice', 'Engineer');