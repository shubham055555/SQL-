-- Advanced SQL Practice
WITH employee_cte AS (SELECT * FROM employees WHERE salary > 50000) SELECT * FROM employee_cte;