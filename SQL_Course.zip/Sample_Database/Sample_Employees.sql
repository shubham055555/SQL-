
-- Sample Employees Table
CREATE TABLE employees (
    id INT PRIMARY KEY,
    name VARCHAR(100),
    role VARCHAR(100),
    salary DECIMAL(10,2)
);

INSERT INTO employees (id, name, role, salary) VALUES
(1, 'Alice', 'Engineer', 70000.00),
(2, 'Bob', 'Manager', 90000.00),
(3, 'Charlie', 'HR', 50000.00);
