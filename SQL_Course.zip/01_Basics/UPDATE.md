# UPDATE Statement
```sql
UPDATE table_name SET column1 = value1 WHERE condition;
```