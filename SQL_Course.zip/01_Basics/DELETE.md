# DELETE Statement
```sql
DELETE FROM table_name WHERE condition;
```