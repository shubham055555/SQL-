# INSERT Statement
```sql
INSERT INTO table_name (column1, column2) VALUES (value1, value2);
```