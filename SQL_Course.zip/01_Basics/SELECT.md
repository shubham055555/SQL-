# SELECT Statement
```sql
SELECT column1, column2 FROM table_name;
```