# WHERE Clause
```sql
SELECT * FROM table_name WHERE condition;
```